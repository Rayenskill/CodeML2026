# Collection Équinoxe — livraison JADCO

Hausse effective : 6.01 %. Hausse contractuelle : 4.72 %.

Ouvrir `final/equinoxe_hausse_2026.ipynb` et `presentation/presentation.pdf`.
La définition, les scénarios et les limites figurent dans `final/README.md`.

Pour reconstruire : installer `final/requirements.txt`, puis depuis `final/` :

```bash
export JADCO_DATA_DIR=/chemin/vers/les/quatre/csv
python release.py --rebuild
```

Les extractions CRM ne sont pas incluses. Les tables publiques sont livrées ; aucun téléchargement n'est nécessaire.
Validation : 36 tests passent, 0 finding de lint.
`MANIFEST.json` contient les empreintes SHA-256 de tous les fichiers du bundle.
